export declare const FilterNameStringType: {
  readonly all: "all";
  readonly description: "description";
  readonly name: "name";
  readonly owning_service: "owning-service";
  readonly primary_region: "primary-region";
  readonly tag_key: "tag-key";
  readonly tag_value: "tag-value";
};
export type FilterNameStringType =
  (typeof FilterNameStringType)[keyof typeof FilterNameStringType];
export declare const StatusType: {
  readonly Failed: "Failed";
  readonly InProgress: "InProgress";
  readonly InSync: "InSync";
};
export type StatusType = (typeof StatusType)[keyof typeof StatusType];
export declare const SortByType: {
  readonly created_date: "created-date";
  readonly last_accessed_date: "last-accessed-date";
  readonly last_changed_date: "last-changed-date";
  readonly name: "name";
};
export type SortByType = (typeof SortByType)[keyof typeof SortByType];
export declare const SortOrderType: {
  readonly asc: "asc";
  readonly desc: "desc";
};
export type SortOrderType = (typeof SortOrderType)[keyof typeof SortOrderType];
