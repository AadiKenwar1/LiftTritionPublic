export declare const isClockSkewed: (
  clockTime: number,
  systemClockOffset: number
) => boolean;
