export declare function jsonReviver(
  key: string,
  value: any,
  context?: {
    source?: string;
  }
): any;
