export declare class JsonReplacer {
  private readonly values;
  private counter;
  private stage;
  createReplacer(): (key: string, value: unknown) => unknown;
  replaceInJson(json: string): string;
}
