import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { CreateSecret$ } from "../schemas/schemas_0";
export { $Command };
export class CreateSecretCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "CreateSecret", {})
    .n("SecretsManagerClient", "CreateSecretCommand")
    .sc(CreateSecret$)
    .build() {
}
