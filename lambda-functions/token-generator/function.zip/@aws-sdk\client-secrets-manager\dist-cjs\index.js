'use strict';

var middlewareHostHeader = require('@aws-sdk/middleware-host-header');
var middlewareLogger = require('@aws-sdk/middleware-logger');
var middlewareRecursionDetection = require('@aws-sdk/middleware-recursion-detection');
var middlewareUserAgent = require('@aws-sdk/middleware-user-agent');
var configResolver = require('@smithy/config-resolver');
var core = require('@smithy/core');
var schema = require('@smithy/core/schema');
var middlewareContentLength = require('@smithy/middleware-content-length');
var middlewareEndpoint = require('@smithy/middleware-endpoint');
var middlewareRetry = require('@smithy/middleware-retry');
var smithyClient = require('@smithy/smithy-client');
var httpAuthSchemeProvider = require('./auth/httpAuthSchemeProvider');
var runtimeConfig = require('./runtimeConfig');
var regionConfigResolver = require('@aws-sdk/region-config-resolver');
var protocolHttp = require('@smithy/protocol-http');

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "secretsmanager",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
};

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(regionConfigResolver.getAwsRegionExtensionConfiguration(runtimeConfig), smithyClient.getDefaultExtensionConfiguration(runtimeConfig), protocolHttp.getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, regionConfigResolver.resolveAwsRegionExtensionConfiguration(extensionConfiguration), smithyClient.resolveDefaultRuntimeConfig(extensionConfiguration), protocolHttp.resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class SecretsManagerClient extends smithyClient.Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = runtimeConfig.getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = middlewareUserAgent.resolveUserAgentConfig(_config_1);
        const _config_3 = middlewareRetry.resolveRetryConfig(_config_2);
        const _config_4 = configResolver.resolveRegionConfig(_config_3);
        const _config_5 = middlewareHostHeader.resolveHostHeaderConfig(_config_4);
        const _config_6 = middlewareEndpoint.resolveEndpointConfig(_config_5);
        const _config_7 = httpAuthSchemeProvider.resolveHttpAuthSchemeConfig(_config_6);
        const _config_8 = resolveRuntimeExtensions(_config_7, configuration?.extensions || []);
        this.config = _config_8;
        this.middlewareStack.use(schema.getSchemaSerdePlugin(this.config));
        this.middlewareStack.use(middlewareUserAgent.getUserAgentPlugin(this.config));
        this.middlewareStack.use(middlewareRetry.getRetryPlugin(this.config));
        this.middlewareStack.use(middlewareContentLength.getContentLengthPlugin(this.config));
        this.middlewareStack.use(middlewareHostHeader.getHostHeaderPlugin(this.config));
        this.middlewareStack.use(middlewareLogger.getLoggerPlugin(this.config));
        this.middlewareStack.use(middlewareRecursionDetection.getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(core.getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: httpAuthSchemeProvider.defaultSecretsManagerHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new core.DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
            }),
        }));
        this.middlewareStack.use(core.getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

class SecretsManagerServiceException extends smithyClient.ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, SecretsManagerServiceException.prototype);
    }
}

class DecryptionFailure extends SecretsManagerServiceException {
    name = "DecryptionFailure";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DecryptionFailure",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DecryptionFailure.prototype);
        this.Message = opts.Message;
    }
}
class InternalServiceError extends SecretsManagerServiceException {
    name = "InternalServiceError";
    $fault = "server";
    Message;
    constructor(opts) {
        super({
            name: "InternalServiceError",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServiceError.prototype);
        this.Message = opts.Message;
    }
}
class InvalidNextTokenException extends SecretsManagerServiceException {
    name = "InvalidNextTokenException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidNextTokenException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidNextTokenException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidParameterException extends SecretsManagerServiceException {
    name = "InvalidParameterException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidParameterException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidParameterException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidRequestException extends SecretsManagerServiceException {
    name = "InvalidRequestException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidRequestException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidRequestException.prototype);
        this.Message = opts.Message;
    }
}
class ResourceNotFoundException extends SecretsManagerServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class EncryptionFailure extends SecretsManagerServiceException {
    name = "EncryptionFailure";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "EncryptionFailure",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, EncryptionFailure.prototype);
        this.Message = opts.Message;
    }
}
class LimitExceededException extends SecretsManagerServiceException {
    name = "LimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "LimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, LimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class MalformedPolicyDocumentException extends SecretsManagerServiceException {
    name = "MalformedPolicyDocumentException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "MalformedPolicyDocumentException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, MalformedPolicyDocumentException.prototype);
        this.Message = opts.Message;
    }
}
class PreconditionNotMetException extends SecretsManagerServiceException {
    name = "PreconditionNotMetException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "PreconditionNotMetException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PreconditionNotMetException.prototype);
        this.Message = opts.Message;
    }
}
class ResourceExistsException extends SecretsManagerServiceException {
    name = "ResourceExistsException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceExistsException.prototype);
        this.Message = opts.Message;
    }
}
class PublicPolicyException extends SecretsManagerServiceException {
    name = "PublicPolicyException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "PublicPolicyException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PublicPolicyException.prototype);
        this.Message = opts.Message;
    }
}

const _AAD = "AutomaticallyAfterDays";
const _APIELT = "APIErrorListType";
const _APIET = "APIErrorType";
const _ARN = "ARN";
const _ARR = "AddReplicaRegions";
const _ARRLT = "AddReplicaRegionListType";
const _BGSV = "BatchGetSecretValue";
const _BGSVR = "BatchGetSecretValueRequest";
const _BGSVRa = "BatchGetSecretValueResponse";
const _BPP = "BlockPublicPolicy";
const _CD = "CreatedDate";
const _CN = "CheckName";
const _CRS = "CancelRotateSecret";
const _CRSR = "CancelRotateSecretRequest";
const _CRSRa = "CancelRotateSecretResponse";
const _CRT = "ClientRequestToken";
const _CS = "CreateSecret";
const _CSR = "CreateSecretRequest";
const _CSRr = "CreateSecretResponse";
const _D = "Description";
const _DD = "DeletionDate";
const _DDe = "DeletedDate";
const _DF = "DecryptionFailure";
const _DRP = "DeleteResourcePolicy";
const _DRPR = "DeleteResourcePolicyRequest";
const _DRPRe = "DeleteResourcePolicyResponse";
const _DS = "DeleteSecret";
const _DSR = "DeleteSecretRequest";
const _DSRe = "DeleteSecretResponse";
const _DSRes = "DescribeSecretRequest";
const _DSResc = "DescribeSecretResponse";
const _DSe = "DescribeSecret";
const _Du = "Duration";
const _E = "Errors";
const _EC = "ErrorCode";
const _ECx = "ExcludeCharacters";
const _EF = "EncryptionFailure";
const _EL = "ExcludeLowercase";
const _EM = "ErrorMessage";
const _EN = "ExcludeNumbers";
const _EP = "ExcludePunctuation";
const _ESRM = "ExternalSecretRotationMetadata";
const _ESRMI = "ExternalSecretRotationMetadataItem";
const _ESRMT = "ExternalSecretRotationMetadataType";
const _ESRRA = "ExternalSecretRotationRoleArn";
const _EU = "ExcludeUppercase";
const _F = "Filters";
const _FDWR = "ForceDeleteWithoutRecovery";
const _FLT = "FiltersListType";
const _FORS = "ForceOverwriteReplicaSecret";
const _Fi = "Filter";
const _GRP = "GetRandomPassword";
const _GRPR = "GetRandomPasswordRequest";
const _GRPRe = "GetRandomPasswordResponse";
const _GRPRet = "GetResourcePolicyRequest";
const _GRPRete = "GetResourcePolicyResponse";
const _GRPe = "GetResourcePolicy";
const _GSV = "GetSecretValue";
const _GSVR = "GetSecretValueRequest";
const _GSVRe = "GetSecretValueResponse";
const _ID = "IncludeDeprecated";
const _INTE = "InvalidNextTokenException";
const _IPD = "IncludePlannedDeletion";
const _IPE = "InvalidParameterException";
const _IRE = "InvalidRequestException";
const _IS = "IncludeSpace";
const _ISE = "InternalServiceError";
const _K = "Key";
const _KKI = "KmsKeyId";
const _KKIm = "KmsKeyIds";
const _LAD = "LastAccessedDate";
const _LCD = "LastChangedDate";
const _LEE = "LimitExceededException";
const _LRD = "LastRotatedDate";
const _LS = "ListSecrets";
const _LSR = "ListSecretsRequest";
const _LSRi = "ListSecretsResponse";
const _LSVI = "ListSecretVersionIds";
const _LSVIR = "ListSecretVersionIdsRequest";
const _LSVIRi = "ListSecretVersionIdsResponse";
const _M = "Message";
const _MPDE = "MalformedPolicyDocumentException";
const _MR = "MaxResults";
const _MTVI = "MoveToVersionId";
const _N = "Name";
const _NRD = "NextRotationDate";
const _NT = "NextToken";
const _OS = "OwningService";
const _PL = "PasswordLength";
const _PNME = "PreconditionNotMetException";
const _PPE = "PublicPolicyException";
const _PR = "PrimaryRegion";
const _PRP = "PutResourcePolicy";
const _PRPR = "PutResourcePolicyRequest";
const _PRPRu = "PutResourcePolicyResponse";
const _PSV = "PutSecretValue";
const _PSVR = "PutSecretValueRequest";
const _PSVRu = "PutSecretValueResponse";
const _PVP = "PolicyValidationPassed";
const _R = "Region";
const _RE = "RotationEnabled";
const _REE = "ResourceExistsException";
const _REIT = "RequireEachIncludedType";
const _RFVI = "RemoveFromVersionId";
const _RI = "RotateImmediately";
const _RLARN = "RotationLambdaARN";
const _RNFE = "ResourceNotFoundException";
const _RP = "RandomPassword";
const _RPT = "RandomPasswordType";
const _RPe = "ResourcePolicy";
const _RR = "RotationRules";
const _RRFR = "RemoveRegionsFromReplication";
const _RRFRR = "RemoveRegionsFromReplicationRequest";
const _RRFRRe = "RemoveRegionsFromReplicationResponse";
const _RRR = "RemoveReplicaRegions";
const _RRT = "ReplicaRegionType";
const _RRTo = "RotationRulesType";
const _RS = "ReplicationStatus";
const _RSLT = "ReplicationStatusListType";
const _RSR = "RestoreSecretRequest";
const _RSRe = "RestoreSecretResponse";
const _RSRo = "RotateSecretRequest";
const _RSRot = "RotateSecretResponse";
const _RST = "ReplicationStatusType";
const _RSTR = "ReplicateSecretToRegions";
const _RSTRR = "ReplicateSecretToRegionsRequest";
const _RSTRRe = "ReplicateSecretToRegionsResponse";
const _RSe = "RestoreSecret";
const _RSo = "RotateSecret";
const _RT = "RotationToken";
const _RTT = "RotationTokenType";
const _RWID = "RecoveryWindowInDays";
const _S = "Status";
const _SB = "SecretBinary";
const _SBT = "SecretBinaryType";
const _SBo = "SortBy";
const _SE = "ScheduleExpression";
const _SI = "SecretId";
const _SIL = "SecretIdList";
const _SL = "SecretList";
const _SLE = "SecretListEntry";
const _SLT = "SecretListType";
const _SM = "StatusMessage";
const _SO = "SortOrder";
const _SRTR = "StopReplicationToReplica";
const _SRTRR = "StopReplicationToReplicaRequest";
const _SRTRRt = "StopReplicationToReplicaResponse";
const _SS = "SecretString";
const _SST = "SecretStringType";
const _SV = "SecretValues";
const _SVE = "SecretValueEntry";
const _SVLE = "SecretVersionsListEntry";
const _SVLT = "SecretVersionsListType";
const _SVT = "SecretValuesType";
const _SVTS = "SecretVersionsToStages";
const _SVTSMT = "SecretVersionsToStagesMapType";
const _T = "Tags";
const _TK = "TagKeys";
const _TLT = "TagListType";
const _TR = "TagResource";
const _TRR = "TagResourceRequest";
const _Ta = "Tag";
const _Ty = "Type";
const _UR = "UntagResource";
const _URR = "UntagResourceRequest";
const _US = "UpdateSecret";
const _USR = "UpdateSecretRequest";
const _USRp = "UpdateSecretResponse";
const _USVS = "UpdateSecretVersionStage";
const _USVSR = "UpdateSecretVersionStageRequest";
const _USVSRp = "UpdateSecretVersionStageResponse";
const _V = "Value";
const _VE = "ValidationErrors";
const _VEE = "ValidationErrorsEntry";
const _VET = "ValidationErrorsType";
const _VI = "VersionId";
const _VITS = "VersionIdsToStages";
const _VRP = "ValidateResourcePolicy";
const _VRPR = "ValidateResourcePolicyRequest";
const _VRPRa = "ValidateResourcePolicyResponse";
const _VS = "VersionStage";
const _VSe = "VersionStages";
const _Va = "Values";
const _Ve = "Versions";
const _c = "client";
const _e = "error";
const _s = "server";
const _sm = "smithy.ts.sdk.synthetic.com.amazonaws.secretsmanager";
const n0 = "com.amazonaws.secretsmanager";
var RandomPasswordType = [0, n0, _RPT, 8, 0];
var RotationTokenType = [0, n0, _RTT, 8, 0];
var SecretBinaryType = [0, n0, _SBT, 8, 21];
var SecretStringType = [0, n0, _SST, 8, 0];
var APIErrorType$ = [3, n0, _APIET,
    0,
    [_SI, _EC, _M],
    [0, 0, 0]
];
var BatchGetSecretValueRequest$ = [3, n0, _BGSVR,
    0,
    [_SIL, _F, _MR, _NT],
    [64 | 0, () => FiltersListType, 1, 0]
];
var BatchGetSecretValueResponse$ = [3, n0, _BGSVRa,
    0,
    [_SV, _NT, _E],
    [[() => SecretValuesType, 0], 0, () => APIErrorListType]
];
var CancelRotateSecretRequest$ = [3, n0, _CRSR,
    0,
    [_SI],
    [0]
];
var CancelRotateSecretResponse$ = [3, n0, _CRSRa,
    0,
    [_ARN, _N, _VI],
    [0, 0, 0]
];
var CreateSecretRequest$ = [3, n0, _CSR,
    0,
    [_N, _CRT, _D, _KKI, _SB, _SS, _T, _ARR, _FORS, _Ty],
    [0, [0, 4], 0, 0, [() => SecretBinaryType, 0], [() => SecretStringType, 0], () => TagListType, () => AddReplicaRegionListType, 2, 0]
];
var CreateSecretResponse$ = [3, n0, _CSRr,
    0,
    [_ARN, _N, _VI, _RS],
    [0, 0, 0, () => ReplicationStatusListType]
];
var DecryptionFailure$ = [-3, n0, _DF,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(DecryptionFailure$, DecryptionFailure);
var DeleteResourcePolicyRequest$ = [3, n0, _DRPR,
    0,
    [_SI],
    [0]
];
var DeleteResourcePolicyResponse$ = [3, n0, _DRPRe,
    0,
    [_ARN, _N],
    [0, 0]
];
var DeleteSecretRequest$ = [3, n0, _DSR,
    0,
    [_SI, _RWID, _FDWR],
    [0, 1, 2]
];
var DeleteSecretResponse$ = [3, n0, _DSRe,
    0,
    [_ARN, _N, _DD],
    [0, 0, 4]
];
var DescribeSecretRequest$ = [3, n0, _DSRes,
    0,
    [_SI],
    [0]
];
var DescribeSecretResponse$ = [3, n0, _DSResc,
    0,
    [_ARN, _N, _Ty, _D, _KKI, _RE, _RLARN, _RR, _ESRM, _ESRRA, _LRD, _LCD, _LAD, _DDe, _NRD, _T, _VITS, _OS, _CD, _PR, _RS],
    [0, 0, 0, 0, 0, 2, 0, () => RotationRulesType$, () => ExternalSecretRotationMetadataType, 0, 4, 4, 4, 4, 4, () => TagListType, [2, n0, _SVTSMT, 0, 0, 64 | 0], 0, 4, 0, () => ReplicationStatusListType]
];
var EncryptionFailure$ = [-3, n0, _EF,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(EncryptionFailure$, EncryptionFailure);
var ExternalSecretRotationMetadataItem$ = [3, n0, _ESRMI,
    0,
    [_K, _V],
    [0, 0]
];
var Filter$ = [3, n0, _Fi,
    0,
    [_K, _Va],
    [0, 64 | 0]
];
var GetRandomPasswordRequest$ = [3, n0, _GRPR,
    0,
    [_PL, _ECx, _EN, _EP, _EU, _EL, _IS, _REIT],
    [1, 0, 2, 2, 2, 2, 2, 2]
];
var GetRandomPasswordResponse$ = [3, n0, _GRPRe,
    0,
    [_RP],
    [[() => RandomPasswordType, 0]]
];
var GetResourcePolicyRequest$ = [3, n0, _GRPRet,
    0,
    [_SI],
    [0]
];
var GetResourcePolicyResponse$ = [3, n0, _GRPRete,
    0,
    [_ARN, _N, _RPe],
    [0, 0, 0]
];
var GetSecretValueRequest$ = [3, n0, _GSVR,
    0,
    [_SI, _VI, _VS],
    [0, 0, 0]
];
var GetSecretValueResponse$ = [3, n0, _GSVRe,
    0,
    [_ARN, _N, _VI, _SB, _SS, _VSe, _CD],
    [0, 0, 0, [() => SecretBinaryType, 0], [() => SecretStringType, 0], 64 | 0, 4]
];
var InternalServiceError$ = [-3, n0, _ISE,
    { [_e]: _s },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(InternalServiceError$, InternalServiceError);
var InvalidNextTokenException$ = [-3, n0, _INTE,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(InvalidNextTokenException$, InvalidNextTokenException);
var InvalidParameterException$ = [-3, n0, _IPE,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(InvalidParameterException$, InvalidParameterException);
var InvalidRequestException$ = [-3, n0, _IRE,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(InvalidRequestException$, InvalidRequestException);
var LimitExceededException$ = [-3, n0, _LEE,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(LimitExceededException$, LimitExceededException);
var ListSecretsRequest$ = [3, n0, _LSR,
    0,
    [_IPD, _MR, _NT, _F, _SO, _SBo],
    [2, 1, 0, () => FiltersListType, 0, 0]
];
var ListSecretsResponse$ = [3, n0, _LSRi,
    0,
    [_SL, _NT],
    [() => SecretListType, 0]
];
var ListSecretVersionIdsRequest$ = [3, n0, _LSVIR,
    0,
    [_SI, _MR, _NT, _ID],
    [0, 1, 0, 2]
];
var ListSecretVersionIdsResponse$ = [3, n0, _LSVIRi,
    0,
    [_Ve, _NT, _ARN, _N],
    [() => SecretVersionsListType, 0, 0, 0]
];
var MalformedPolicyDocumentException$ = [-3, n0, _MPDE,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(MalformedPolicyDocumentException$, MalformedPolicyDocumentException);
var PreconditionNotMetException$ = [-3, n0, _PNME,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(PreconditionNotMetException$, PreconditionNotMetException);
var PublicPolicyException$ = [-3, n0, _PPE,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(PublicPolicyException$, PublicPolicyException);
var PutResourcePolicyRequest$ = [3, n0, _PRPR,
    0,
    [_SI, _RPe, _BPP],
    [0, 0, 2]
];
var PutResourcePolicyResponse$ = [3, n0, _PRPRu,
    0,
    [_ARN, _N],
    [0, 0]
];
var PutSecretValueRequest$ = [3, n0, _PSVR,
    0,
    [_SI, _CRT, _SB, _SS, _VSe, _RT],
    [0, [0, 4], [() => SecretBinaryType, 0], [() => SecretStringType, 0], 64 | 0, [() => RotationTokenType, 0]]
];
var PutSecretValueResponse$ = [3, n0, _PSVRu,
    0,
    [_ARN, _N, _VI, _VSe],
    [0, 0, 0, 64 | 0]
];
var RemoveRegionsFromReplicationRequest$ = [3, n0, _RRFRR,
    0,
    [_SI, _RRR],
    [0, 64 | 0]
];
var RemoveRegionsFromReplicationResponse$ = [3, n0, _RRFRRe,
    0,
    [_ARN, _RS],
    [0, () => ReplicationStatusListType]
];
var ReplicaRegionType$ = [3, n0, _RRT,
    0,
    [_R, _KKI],
    [0, 0]
];
var ReplicateSecretToRegionsRequest$ = [3, n0, _RSTRR,
    0,
    [_SI, _ARR, _FORS],
    [0, () => AddReplicaRegionListType, 2]
];
var ReplicateSecretToRegionsResponse$ = [3, n0, _RSTRRe,
    0,
    [_ARN, _RS],
    [0, () => ReplicationStatusListType]
];
var ReplicationStatusType$ = [3, n0, _RST,
    0,
    [_R, _KKI, _S, _SM, _LAD],
    [0, 0, 0, 0, 4]
];
var ResourceExistsException$ = [-3, n0, _REE,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(ResourceExistsException$, ResourceExistsException);
var ResourceNotFoundException$ = [-3, n0, _RNFE,
    { [_e]: _c },
    [_M],
    [0]
];
schema.TypeRegistry.for(n0).registerError(ResourceNotFoundException$, ResourceNotFoundException);
var RestoreSecretRequest$ = [3, n0, _RSR,
    0,
    [_SI],
    [0]
];
var RestoreSecretResponse$ = [3, n0, _RSRe,
    0,
    [_ARN, _N],
    [0, 0]
];
var RotateSecretRequest$ = [3, n0, _RSRo,
    0,
    [_SI, _CRT, _RLARN, _RR, _ESRM, _ESRRA, _RI],
    [0, [0, 4], 0, () => RotationRulesType$, () => ExternalSecretRotationMetadataType, 0, 2]
];
var RotateSecretResponse$ = [3, n0, _RSRot,
    0,
    [_ARN, _N, _VI],
    [0, 0, 0]
];
var RotationRulesType$ = [3, n0, _RRTo,
    0,
    [_AAD, _Du, _SE],
    [1, 0, 0]
];
var SecretListEntry$ = [3, n0, _SLE,
    0,
    [_ARN, _N, _Ty, _D, _KKI, _RE, _RLARN, _RR, _ESRM, _ESRRA, _LRD, _LCD, _LAD, _DDe, _NRD, _T, _SVTS, _OS, _CD, _PR],
    [0, 0, 0, 0, 0, 2, 0, () => RotationRulesType$, () => ExternalSecretRotationMetadataType, 0, 4, 4, 4, 4, 4, () => TagListType, [2, n0, _SVTSMT, 0, 0, 64 | 0], 0, 4, 0]
];
var SecretValueEntry$ = [3, n0, _SVE,
    0,
    [_ARN, _N, _VI, _SB, _SS, _VSe, _CD],
    [0, 0, 0, [() => SecretBinaryType, 0], [() => SecretStringType, 0], 64 | 0, 4]
];
var SecretVersionsListEntry$ = [3, n0, _SVLE,
    0,
    [_VI, _VSe, _LAD, _CD, _KKIm],
    [0, 64 | 0, 4, 4, 64 | 0]
];
var StopReplicationToReplicaRequest$ = [3, n0, _SRTRR,
    0,
    [_SI],
    [0]
];
var StopReplicationToReplicaResponse$ = [3, n0, _SRTRRt,
    0,
    [_ARN],
    [0]
];
var Tag$ = [3, n0, _Ta,
    0,
    [_K, _V],
    [0, 0]
];
var TagResourceRequest$ = [3, n0, _TRR,
    0,
    [_SI, _T],
    [0, () => TagListType]
];
var UntagResourceRequest$ = [3, n0, _URR,
    0,
    [_SI, _TK],
    [0, 64 | 0]
];
var UpdateSecretRequest$ = [3, n0, _USR,
    0,
    [_SI, _CRT, _D, _KKI, _SB, _SS, _Ty],
    [0, [0, 4], 0, 0, [() => SecretBinaryType, 0], [() => SecretStringType, 0], 0]
];
var UpdateSecretResponse$ = [3, n0, _USRp,
    0,
    [_ARN, _N, _VI],
    [0, 0, 0]
];
var UpdateSecretVersionStageRequest$ = [3, n0, _USVSR,
    0,
    [_SI, _VS, _RFVI, _MTVI],
    [0, 0, 0, 0]
];
var UpdateSecretVersionStageResponse$ = [3, n0, _USVSRp,
    0,
    [_ARN, _N],
    [0, 0]
];
var ValidateResourcePolicyRequest$ = [3, n0, _VRPR,
    0,
    [_SI, _RPe],
    [0, 0]
];
var ValidateResourcePolicyResponse$ = [3, n0, _VRPRa,
    0,
    [_PVP, _VE],
    [2, () => ValidationErrorsType]
];
var ValidationErrorsEntry$ = [3, n0, _VEE,
    0,
    [_CN, _EM],
    [0, 0]
];
var __Unit = "unit";
var SecretsManagerServiceException$ = [-3, _sm, "SecretsManagerServiceException", 0, [], []];
schema.TypeRegistry.for(_sm).registerError(SecretsManagerServiceException$, SecretsManagerServiceException);
var AddReplicaRegionListType = [1, n0, _ARRLT,
    0, () => ReplicaRegionType$
];
var APIErrorListType = [1, n0, _APIELT,
    0, () => APIErrorType$
];
var ExternalSecretRotationMetadataType = [1, n0, _ESRMT,
    0, () => ExternalSecretRotationMetadataItem$
];
var FiltersListType = [1, n0, _FLT,
    0, () => Filter$
];
var ReplicationStatusListType = [1, n0, _RSLT,
    0, () => ReplicationStatusType$
];
var SecretListType = [1, n0, _SLT,
    0, () => SecretListEntry$
];
var SecretValuesType = [1, n0, _SVT,
    0, [() => SecretValueEntry$,
        0]
];
var SecretVersionsListType = [1, n0, _SVLT,
    0, () => SecretVersionsListEntry$
];
var TagListType = [1, n0, _TLT,
    0, () => Tag$
];
var ValidationErrorsType = [1, n0, _VET,
    0, () => ValidationErrorsEntry$
];
var BatchGetSecretValue$ = [9, n0, _BGSV,
    0, () => BatchGetSecretValueRequest$, () => BatchGetSecretValueResponse$
];
var CancelRotateSecret$ = [9, n0, _CRS,
    0, () => CancelRotateSecretRequest$, () => CancelRotateSecretResponse$
];
var CreateSecret$ = [9, n0, _CS,
    0, () => CreateSecretRequest$, () => CreateSecretResponse$
];
var DeleteResourcePolicy$ = [9, n0, _DRP,
    0, () => DeleteResourcePolicyRequest$, () => DeleteResourcePolicyResponse$
];
var DeleteSecret$ = [9, n0, _DS,
    0, () => DeleteSecretRequest$, () => DeleteSecretResponse$
];
var DescribeSecret$ = [9, n0, _DSe,
    0, () => DescribeSecretRequest$, () => DescribeSecretResponse$
];
var GetRandomPassword$ = [9, n0, _GRP,
    0, () => GetRandomPasswordRequest$, () => GetRandomPasswordResponse$
];
var GetResourcePolicy$ = [9, n0, _GRPe,
    0, () => GetResourcePolicyRequest$, () => GetResourcePolicyResponse$
];
var GetSecretValue$ = [9, n0, _GSV,
    0, () => GetSecretValueRequest$, () => GetSecretValueResponse$
];
var ListSecrets$ = [9, n0, _LS,
    0, () => ListSecretsRequest$, () => ListSecretsResponse$
];
var ListSecretVersionIds$ = [9, n0, _LSVI,
    0, () => ListSecretVersionIdsRequest$, () => ListSecretVersionIdsResponse$
];
var PutResourcePolicy$ = [9, n0, _PRP,
    0, () => PutResourcePolicyRequest$, () => PutResourcePolicyResponse$
];
var PutSecretValue$ = [9, n0, _PSV,
    0, () => PutSecretValueRequest$, () => PutSecretValueResponse$
];
var RemoveRegionsFromReplication$ = [9, n0, _RRFR,
    0, () => RemoveRegionsFromReplicationRequest$, () => RemoveRegionsFromReplicationResponse$
];
var ReplicateSecretToRegions$ = [9, n0, _RSTR,
    0, () => ReplicateSecretToRegionsRequest$, () => ReplicateSecretToRegionsResponse$
];
var RestoreSecret$ = [9, n0, _RSe,
    0, () => RestoreSecretRequest$, () => RestoreSecretResponse$
];
var RotateSecret$ = [9, n0, _RSo,
    0, () => RotateSecretRequest$, () => RotateSecretResponse$
];
var StopReplicationToReplica$ = [9, n0, _SRTR,
    0, () => StopReplicationToReplicaRequest$, () => StopReplicationToReplicaResponse$
];
var TagResource$ = [9, n0, _TR,
    0, () => TagResourceRequest$, () => __Unit
];
var UntagResource$ = [9, n0, _UR,
    0, () => UntagResourceRequest$, () => __Unit
];
var UpdateSecret$ = [9, n0, _US,
    0, () => UpdateSecretRequest$, () => UpdateSecretResponse$
];
var UpdateSecretVersionStage$ = [9, n0, _USVS,
    0, () => UpdateSecretVersionStageRequest$, () => UpdateSecretVersionStageResponse$
];
var ValidateResourcePolicy$ = [9, n0, _VRP,
    0, () => ValidateResourcePolicyRequest$, () => ValidateResourcePolicyResponse$
];

class BatchGetSecretValueCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "BatchGetSecretValue", {})
    .n("SecretsManagerClient", "BatchGetSecretValueCommand")
    .sc(BatchGetSecretValue$)
    .build() {
}

class CancelRotateSecretCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "CancelRotateSecret", {})
    .n("SecretsManagerClient", "CancelRotateSecretCommand")
    .sc(CancelRotateSecret$)
    .build() {
}

class CreateSecretCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "CreateSecret", {})
    .n("SecretsManagerClient", "CreateSecretCommand")
    .sc(CreateSecret$)
    .build() {
}

class DeleteResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "DeleteResourcePolicy", {})
    .n("SecretsManagerClient", "DeleteResourcePolicyCommand")
    .sc(DeleteResourcePolicy$)
    .build() {
}

class DeleteSecretCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "DeleteSecret", {})
    .n("SecretsManagerClient", "DeleteSecretCommand")
    .sc(DeleteSecret$)
    .build() {
}

class DescribeSecretCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "DescribeSecret", {})
    .n("SecretsManagerClient", "DescribeSecretCommand")
    .sc(DescribeSecret$)
    .build() {
}

class GetRandomPasswordCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "GetRandomPassword", {})
    .n("SecretsManagerClient", "GetRandomPasswordCommand")
    .sc(GetRandomPassword$)
    .build() {
}

class GetResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "GetResourcePolicy", {})
    .n("SecretsManagerClient", "GetResourcePolicyCommand")
    .sc(GetResourcePolicy$)
    .build() {
}

class GetSecretValueCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "GetSecretValue", {})
    .n("SecretsManagerClient", "GetSecretValueCommand")
    .sc(GetSecretValue$)
    .build() {
}

class ListSecretsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "ListSecrets", {})
    .n("SecretsManagerClient", "ListSecretsCommand")
    .sc(ListSecrets$)
    .build() {
}

class ListSecretVersionIdsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "ListSecretVersionIds", {})
    .n("SecretsManagerClient", "ListSecretVersionIdsCommand")
    .sc(ListSecretVersionIds$)
    .build() {
}

class PutResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "PutResourcePolicy", {})
    .n("SecretsManagerClient", "PutResourcePolicyCommand")
    .sc(PutResourcePolicy$)
    .build() {
}

class PutSecretValueCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "PutSecretValue", {})
    .n("SecretsManagerClient", "PutSecretValueCommand")
    .sc(PutSecretValue$)
    .build() {
}

class RemoveRegionsFromReplicationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "RemoveRegionsFromReplication", {})
    .n("SecretsManagerClient", "RemoveRegionsFromReplicationCommand")
    .sc(RemoveRegionsFromReplication$)
    .build() {
}

class ReplicateSecretToRegionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "ReplicateSecretToRegions", {})
    .n("SecretsManagerClient", "ReplicateSecretToRegionsCommand")
    .sc(ReplicateSecretToRegions$)
    .build() {
}

class RestoreSecretCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "RestoreSecret", {})
    .n("SecretsManagerClient", "RestoreSecretCommand")
    .sc(RestoreSecret$)
    .build() {
}

class RotateSecretCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "RotateSecret", {})
    .n("SecretsManagerClient", "RotateSecretCommand")
    .sc(RotateSecret$)
    .build() {
}

class StopReplicationToReplicaCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "StopReplicationToReplica", {})
    .n("SecretsManagerClient", "StopReplicationToReplicaCommand")
    .sc(StopReplicationToReplica$)
    .build() {
}

class TagResourceCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "TagResource", {})
    .n("SecretsManagerClient", "TagResourceCommand")
    .sc(TagResource$)
    .build() {
}

class UntagResourceCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "UntagResource", {})
    .n("SecretsManagerClient", "UntagResourceCommand")
    .sc(UntagResource$)
    .build() {
}

class UpdateSecretCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "UpdateSecret", {})
    .n("SecretsManagerClient", "UpdateSecretCommand")
    .sc(UpdateSecret$)
    .build() {
}

class UpdateSecretVersionStageCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "UpdateSecretVersionStage", {})
    .n("SecretsManagerClient", "UpdateSecretVersionStageCommand")
    .sc(UpdateSecretVersionStage$)
    .build() {
}

class ValidateResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("secretsmanager", "ValidateResourcePolicy", {})
    .n("SecretsManagerClient", "ValidateResourcePolicyCommand")
    .sc(ValidateResourcePolicy$)
    .build() {
}

const commands = {
    BatchGetSecretValueCommand,
    CancelRotateSecretCommand,
    CreateSecretCommand,
    DeleteResourcePolicyCommand,
    DeleteSecretCommand,
    DescribeSecretCommand,
    GetRandomPasswordCommand,
    GetResourcePolicyCommand,
    GetSecretValueCommand,
    ListSecretsCommand,
    ListSecretVersionIdsCommand,
    PutResourcePolicyCommand,
    PutSecretValueCommand,
    RemoveRegionsFromReplicationCommand,
    ReplicateSecretToRegionsCommand,
    RestoreSecretCommand,
    RotateSecretCommand,
    StopReplicationToReplicaCommand,
    TagResourceCommand,
    UntagResourceCommand,
    UpdateSecretCommand,
    UpdateSecretVersionStageCommand,
    ValidateResourcePolicyCommand,
};
class SecretsManager extends SecretsManagerClient {
}
smithyClient.createAggregatedClient(commands, SecretsManager);

const paginateBatchGetSecretValue = core.createPaginator(SecretsManagerClient, BatchGetSecretValueCommand, "NextToken", "NextToken", "MaxResults");

const paginateListSecrets = core.createPaginator(SecretsManagerClient, ListSecretsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListSecretVersionIds = core.createPaginator(SecretsManagerClient, ListSecretVersionIdsCommand, "NextToken", "NextToken", "MaxResults");

const FilterNameStringType = {
    all: "all",
    description: "description",
    name: "name",
    owning_service: "owning-service",
    primary_region: "primary-region",
    tag_key: "tag-key",
    tag_value: "tag-value",
};
const StatusType = {
    Failed: "Failed",
    InProgress: "InProgress",
    InSync: "InSync",
};
const SortByType = {
    created_date: "created-date",
    last_accessed_date: "last-accessed-date",
    last_changed_date: "last-changed-date",
    name: "name",
};
const SortOrderType = {
    asc: "asc",
    desc: "desc",
};

Object.defineProperty(exports, "$Command", {
    enumerable: true,
    get: function () { return smithyClient.Command; }
});
Object.defineProperty(exports, "__Client", {
    enumerable: true,
    get: function () { return smithyClient.Client; }
});
exports.APIErrorType$ = APIErrorType$;
exports.BatchGetSecretValue$ = BatchGetSecretValue$;
exports.BatchGetSecretValueCommand = BatchGetSecretValueCommand;
exports.BatchGetSecretValueRequest$ = BatchGetSecretValueRequest$;
exports.BatchGetSecretValueResponse$ = BatchGetSecretValueResponse$;
exports.CancelRotateSecret$ = CancelRotateSecret$;
exports.CancelRotateSecretCommand = CancelRotateSecretCommand;
exports.CancelRotateSecretRequest$ = CancelRotateSecretRequest$;
exports.CancelRotateSecretResponse$ = CancelRotateSecretResponse$;
exports.CreateSecret$ = CreateSecret$;
exports.CreateSecretCommand = CreateSecretCommand;
exports.CreateSecretRequest$ = CreateSecretRequest$;
exports.CreateSecretResponse$ = CreateSecretResponse$;
exports.DecryptionFailure = DecryptionFailure;
exports.DecryptionFailure$ = DecryptionFailure$;
exports.DeleteResourcePolicy$ = DeleteResourcePolicy$;
exports.DeleteResourcePolicyCommand = DeleteResourcePolicyCommand;
exports.DeleteResourcePolicyRequest$ = DeleteResourcePolicyRequest$;
exports.DeleteResourcePolicyResponse$ = DeleteResourcePolicyResponse$;
exports.DeleteSecret$ = DeleteSecret$;
exports.DeleteSecretCommand = DeleteSecretCommand;
exports.DeleteSecretRequest$ = DeleteSecretRequest$;
exports.DeleteSecretResponse$ = DeleteSecretResponse$;
exports.DescribeSecret$ = DescribeSecret$;
exports.DescribeSecretCommand = DescribeSecretCommand;
exports.DescribeSecretRequest$ = DescribeSecretRequest$;
exports.DescribeSecretResponse$ = DescribeSecretResponse$;
exports.EncryptionFailure = EncryptionFailure;
exports.EncryptionFailure$ = EncryptionFailure$;
exports.ExternalSecretRotationMetadataItem$ = ExternalSecretRotationMetadataItem$;
exports.Filter$ = Filter$;
exports.FilterNameStringType = FilterNameStringType;
exports.GetRandomPassword$ = GetRandomPassword$;
exports.GetRandomPasswordCommand = GetRandomPasswordCommand;
exports.GetRandomPasswordRequest$ = GetRandomPasswordRequest$;
exports.GetRandomPasswordResponse$ = GetRandomPasswordResponse$;
exports.GetResourcePolicy$ = GetResourcePolicy$;
exports.GetResourcePolicyCommand = GetResourcePolicyCommand;
exports.GetResourcePolicyRequest$ = GetResourcePolicyRequest$;
exports.GetResourcePolicyResponse$ = GetResourcePolicyResponse$;
exports.GetSecretValue$ = GetSecretValue$;
exports.GetSecretValueCommand = GetSecretValueCommand;
exports.GetSecretValueRequest$ = GetSecretValueRequest$;
exports.GetSecretValueResponse$ = GetSecretValueResponse$;
exports.InternalServiceError = InternalServiceError;
exports.InternalServiceError$ = InternalServiceError$;
exports.InvalidNextTokenException = InvalidNextTokenException;
exports.InvalidNextTokenException$ = InvalidNextTokenException$;
exports.InvalidParameterException = InvalidParameterException;
exports.InvalidParameterException$ = InvalidParameterException$;
exports.InvalidRequestException = InvalidRequestException;
exports.InvalidRequestException$ = InvalidRequestException$;
exports.LimitExceededException = LimitExceededException;
exports.LimitExceededException$ = LimitExceededException$;
exports.ListSecretVersionIds$ = ListSecretVersionIds$;
exports.ListSecretVersionIdsCommand = ListSecretVersionIdsCommand;
exports.ListSecretVersionIdsRequest$ = ListSecretVersionIdsRequest$;
exports.ListSecretVersionIdsResponse$ = ListSecretVersionIdsResponse$;
exports.ListSecrets$ = ListSecrets$;
exports.ListSecretsCommand = ListSecretsCommand;
exports.ListSecretsRequest$ = ListSecretsRequest$;
exports.ListSecretsResponse$ = ListSecretsResponse$;
exports.MalformedPolicyDocumentException = MalformedPolicyDocumentException;
exports.MalformedPolicyDocumentException$ = MalformedPolicyDocumentException$;
exports.PreconditionNotMetException = PreconditionNotMetException;
exports.PreconditionNotMetException$ = PreconditionNotMetException$;
exports.PublicPolicyException = PublicPolicyException;
exports.PublicPolicyException$ = PublicPolicyException$;
exports.PutResourcePolicy$ = PutResourcePolicy$;
exports.PutResourcePolicyCommand = PutResourcePolicyCommand;
exports.PutResourcePolicyRequest$ = PutResourcePolicyRequest$;
exports.PutResourcePolicyResponse$ = PutResourcePolicyResponse$;
exports.PutSecretValue$ = PutSecretValue$;
exports.PutSecretValueCommand = PutSecretValueCommand;
exports.PutSecretValueRequest$ = PutSecretValueRequest$;
exports.PutSecretValueResponse$ = PutSecretValueResponse$;
exports.RemoveRegionsFromReplication$ = RemoveRegionsFromReplication$;
exports.RemoveRegionsFromReplicationCommand = RemoveRegionsFromReplicationCommand;
exports.RemoveRegionsFromReplicationRequest$ = RemoveRegionsFromReplicationRequest$;
exports.RemoveRegionsFromReplicationResponse$ = RemoveRegionsFromReplicationResponse$;
exports.ReplicaRegionType$ = ReplicaRegionType$;
exports.ReplicateSecretToRegions$ = ReplicateSecretToRegions$;
exports.ReplicateSecretToRegionsCommand = ReplicateSecretToRegionsCommand;
exports.ReplicateSecretToRegionsRequest$ = ReplicateSecretToRegionsRequest$;
exports.ReplicateSecretToRegionsResponse$ = ReplicateSecretToRegionsResponse$;
exports.ReplicationStatusType$ = ReplicationStatusType$;
exports.ResourceExistsException = ResourceExistsException;
exports.ResourceExistsException$ = ResourceExistsException$;
exports.ResourceNotFoundException = ResourceNotFoundException;
exports.ResourceNotFoundException$ = ResourceNotFoundException$;
exports.RestoreSecret$ = RestoreSecret$;
exports.RestoreSecretCommand = RestoreSecretCommand;
exports.RestoreSecretRequest$ = RestoreSecretRequest$;
exports.RestoreSecretResponse$ = RestoreSecretResponse$;
exports.RotateSecret$ = RotateSecret$;
exports.RotateSecretCommand = RotateSecretCommand;
exports.RotateSecretRequest$ = RotateSecretRequest$;
exports.RotateSecretResponse$ = RotateSecretResponse$;
exports.RotationRulesType$ = RotationRulesType$;
exports.SecretListEntry$ = SecretListEntry$;
exports.SecretValueEntry$ = SecretValueEntry$;
exports.SecretVersionsListEntry$ = SecretVersionsListEntry$;
exports.SecretsManager = SecretsManager;
exports.SecretsManagerClient = SecretsManagerClient;
exports.SecretsManagerServiceException = SecretsManagerServiceException;
exports.SecretsManagerServiceException$ = SecretsManagerServiceException$;
exports.SortByType = SortByType;
exports.SortOrderType = SortOrderType;
exports.StatusType = StatusType;
exports.StopReplicationToReplica$ = StopReplicationToReplica$;
exports.StopReplicationToReplicaCommand = StopReplicationToReplicaCommand;
exports.StopReplicationToReplicaRequest$ = StopReplicationToReplicaRequest$;
exports.StopReplicationToReplicaResponse$ = StopReplicationToReplicaResponse$;
exports.Tag$ = Tag$;
exports.TagResource$ = TagResource$;
exports.TagResourceCommand = TagResourceCommand;
exports.TagResourceRequest$ = TagResourceRequest$;
exports.UntagResource$ = UntagResource$;
exports.UntagResourceCommand = UntagResourceCommand;
exports.UntagResourceRequest$ = UntagResourceRequest$;
exports.UpdateSecret$ = UpdateSecret$;
exports.UpdateSecretCommand = UpdateSecretCommand;
exports.UpdateSecretRequest$ = UpdateSecretRequest$;
exports.UpdateSecretResponse$ = UpdateSecretResponse$;
exports.UpdateSecretVersionStage$ = UpdateSecretVersionStage$;
exports.UpdateSecretVersionStageCommand = UpdateSecretVersionStageCommand;
exports.UpdateSecretVersionStageRequest$ = UpdateSecretVersionStageRequest$;
exports.UpdateSecretVersionStageResponse$ = UpdateSecretVersionStageResponse$;
exports.ValidateResourcePolicy$ = ValidateResourcePolicy$;
exports.ValidateResourcePolicyCommand = ValidateResourcePolicyCommand;
exports.ValidateResourcePolicyRequest$ = ValidateResourcePolicyRequest$;
exports.ValidateResourcePolicyResponse$ = ValidateResourcePolicyResponse$;
exports.ValidationErrorsEntry$ = ValidationErrorsEntry$;
exports.paginateBatchGetSecretValue = paginateBatchGetSecretValue;
exports.paginateListSecretVersionIds = paginateListSecretVersionIds;
exports.paginateListSecrets = paginateListSecrets;
