/**
 * Formats XML, for testing only.
 * @internal
 * @deprecated don't use in runtime code.
 */
export declare function simpleFormatXml(xml: string): string;
