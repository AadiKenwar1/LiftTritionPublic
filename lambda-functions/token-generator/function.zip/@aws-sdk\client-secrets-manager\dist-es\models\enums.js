export const FilterNameStringType = {
    all: "all",
    description: "description",
    name: "name",
    owning_service: "owning-service",
    primary_region: "primary-region",
    tag_key: "tag-key",
    tag_value: "tag-value",
};
export const StatusType = {
    Failed: "Failed",
    InProgress: "InProgress",
    InSync: "InSync",
};
export const SortByType = {
    created_date: "created-date",
    last_accessed_date: "last-accessed-date",
    last_changed_date: "last-changed-date",
    name: "name",
};
export const SortOrderType = {
    asc: "asc",
    desc: "desc",
};
