export const getSkewCorrectedDate = (systemClockOffset) => new Date(Date.now() + systemClockOffset);
