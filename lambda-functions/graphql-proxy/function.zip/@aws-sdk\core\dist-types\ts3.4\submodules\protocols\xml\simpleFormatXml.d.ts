export declare function simpleFormatXml(xml: string): string;
