import {
  FilterNameStringType,
  SortByType,
  SortOrderType,
  StatusType,
} from "./enums";
export interface ReplicaRegionType {
  Region?: string | undefined;
  KmsKeyId?: string | undefined;
}
export interface APIErrorType {
  SecretId?: string | undefined;
  ErrorCode?: string | undefined;
  Message?: string | undefined;
}
export interface Filter {
  Key?: FilterNameStringType | undefined;
  Values?: string[] | undefined;
}
export interface BatchGetSecretValueRequest {
  SecretIdList?: string[] | undefined;
  Filters?: Filter[] | undefined;
  MaxResults?: number | undefined;
  NextToken?: string | undefined;
}
export interface SecretValueEntry {
  ARN?: string | undefined;
  Name?: string | undefined;
  VersionId?: string | undefined;
  SecretBinary?: Uint8Array | undefined;
  SecretString?: string | undefined;
  VersionStages?: string[] | undefined;
  CreatedDate?: Date | undefined;
}
export interface BatchGetSecretValueResponse {
  SecretValues?: SecretValueEntry[] | undefined;
  NextToken?: string | undefined;
  Errors?: APIErrorType[] | undefined;
}
export interface CancelRotateSecretRequest {
  SecretId: string | undefined;
}
export interface CancelRotateSecretResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  VersionId?: string | undefined;
}
export interface Tag {
  Key?: string | undefined;
  Value?: string | undefined;
}
export interface CreateSecretRequest {
  Name: string | undefined;
  ClientRequestToken?: string | undefined;
  Description?: string | undefined;
  KmsKeyId?: string | undefined;
  SecretBinary?: Uint8Array | undefined;
  SecretString?: string | undefined;
  Tags?: Tag[] | undefined;
  AddReplicaRegions?: ReplicaRegionType[] | undefined;
  ForceOverwriteReplicaSecret?: boolean | undefined;
  Type?: string | undefined;
}
export interface ReplicationStatusType {
  Region?: string | undefined;
  KmsKeyId?: string | undefined;
  Status?: StatusType | undefined;
  StatusMessage?: string | undefined;
  LastAccessedDate?: Date | undefined;
}
export interface CreateSecretResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  VersionId?: string | undefined;
  ReplicationStatus?: ReplicationStatusType[] | undefined;
}
export interface DeleteResourcePolicyRequest {
  SecretId: string | undefined;
}
export interface DeleteResourcePolicyResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
}
export interface DeleteSecretRequest {
  SecretId: string | undefined;
  RecoveryWindowInDays?: number | undefined;
  ForceDeleteWithoutRecovery?: boolean | undefined;
}
export interface DeleteSecretResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  DeletionDate?: Date | undefined;
}
export interface DescribeSecretRequest {
  SecretId: string | undefined;
}
export interface ExternalSecretRotationMetadataItem {
  Key?: string | undefined;
  Value?: string | undefined;
}
export interface RotationRulesType {
  AutomaticallyAfterDays?: number | undefined;
  Duration?: string | undefined;
  ScheduleExpression?: string | undefined;
}
export interface DescribeSecretResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  Type?: string | undefined;
  Description?: string | undefined;
  KmsKeyId?: string | undefined;
  RotationEnabled?: boolean | undefined;
  RotationLambdaARN?: string | undefined;
  RotationRules?: RotationRulesType | undefined;
  ExternalSecretRotationMetadata?:
    | ExternalSecretRotationMetadataItem[]
    | undefined;
  ExternalSecretRotationRoleArn?: string | undefined;
  LastRotatedDate?: Date | undefined;
  LastChangedDate?: Date | undefined;
  LastAccessedDate?: Date | undefined;
  DeletedDate?: Date | undefined;
  NextRotationDate?: Date | undefined;
  Tags?: Tag[] | undefined;
  VersionIdsToStages?: Record<string, string[]> | undefined;
  OwningService?: string | undefined;
  CreatedDate?: Date | undefined;
  PrimaryRegion?: string | undefined;
  ReplicationStatus?: ReplicationStatusType[] | undefined;
}
export interface GetRandomPasswordRequest {
  PasswordLength?: number | undefined;
  ExcludeCharacters?: string | undefined;
  ExcludeNumbers?: boolean | undefined;
  ExcludePunctuation?: boolean | undefined;
  ExcludeUppercase?: boolean | undefined;
  ExcludeLowercase?: boolean | undefined;
  IncludeSpace?: boolean | undefined;
  RequireEachIncludedType?: boolean | undefined;
}
export interface GetRandomPasswordResponse {
  RandomPassword?: string | undefined;
}
export interface GetResourcePolicyRequest {
  SecretId: string | undefined;
}
export interface GetResourcePolicyResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  ResourcePolicy?: string | undefined;
}
export interface GetSecretValueRequest {
  SecretId: string | undefined;
  VersionId?: string | undefined;
  VersionStage?: string | undefined;
}
export interface GetSecretValueResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  VersionId?: string | undefined;
  SecretBinary?: Uint8Array | undefined;
  SecretString?: string | undefined;
  VersionStages?: string[] | undefined;
  CreatedDate?: Date | undefined;
}
export interface ListSecretsRequest {
  IncludePlannedDeletion?: boolean | undefined;
  MaxResults?: number | undefined;
  NextToken?: string | undefined;
  Filters?: Filter[] | undefined;
  SortOrder?: SortOrderType | undefined;
  SortBy?: SortByType | undefined;
}
export interface SecretListEntry {
  ARN?: string | undefined;
  Name?: string | undefined;
  Type?: string | undefined;
  Description?: string | undefined;
  KmsKeyId?: string | undefined;
  RotationEnabled?: boolean | undefined;
  RotationLambdaARN?: string | undefined;
  RotationRules?: RotationRulesType | undefined;
  ExternalSecretRotationMetadata?:
    | ExternalSecretRotationMetadataItem[]
    | undefined;
  ExternalSecretRotationRoleArn?: string | undefined;
  LastRotatedDate?: Date | undefined;
  LastChangedDate?: Date | undefined;
  LastAccessedDate?: Date | undefined;
  DeletedDate?: Date | undefined;
  NextRotationDate?: Date | undefined;
  Tags?: Tag[] | undefined;
  SecretVersionsToStages?: Record<string, string[]> | undefined;
  OwningService?: string | undefined;
  CreatedDate?: Date | undefined;
  PrimaryRegion?: string | undefined;
}
export interface ListSecretsResponse {
  SecretList?: SecretListEntry[] | undefined;
  NextToken?: string | undefined;
}
export interface ListSecretVersionIdsRequest {
  SecretId: string | undefined;
  MaxResults?: number | undefined;
  NextToken?: string | undefined;
  IncludeDeprecated?: boolean | undefined;
}
export interface SecretVersionsListEntry {
  VersionId?: string | undefined;
  VersionStages?: string[] | undefined;
  LastAccessedDate?: Date | undefined;
  CreatedDate?: Date | undefined;
  KmsKeyIds?: string[] | undefined;
}
export interface ListSecretVersionIdsResponse {
  Versions?: SecretVersionsListEntry[] | undefined;
  NextToken?: string | undefined;
  ARN?: string | undefined;
  Name?: string | undefined;
}
export interface PutResourcePolicyRequest {
  SecretId: string | undefined;
  ResourcePolicy: string | undefined;
  BlockPublicPolicy?: boolean | undefined;
}
export interface PutResourcePolicyResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
}
export interface PutSecretValueRequest {
  SecretId: string | undefined;
  ClientRequestToken?: string | undefined;
  SecretBinary?: Uint8Array | undefined;
  SecretString?: string | undefined;
  VersionStages?: string[] | undefined;
  RotationToken?: string | undefined;
}
export interface PutSecretValueResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  VersionId?: string | undefined;
  VersionStages?: string[] | undefined;
}
export interface RemoveRegionsFromReplicationRequest {
  SecretId: string | undefined;
  RemoveReplicaRegions: string[] | undefined;
}
export interface RemoveRegionsFromReplicationResponse {
  ARN?: string | undefined;
  ReplicationStatus?: ReplicationStatusType[] | undefined;
}
export interface ReplicateSecretToRegionsRequest {
  SecretId: string | undefined;
  AddReplicaRegions: ReplicaRegionType[] | undefined;
  ForceOverwriteReplicaSecret?: boolean | undefined;
}
export interface ReplicateSecretToRegionsResponse {
  ARN?: string | undefined;
  ReplicationStatus?: ReplicationStatusType[] | undefined;
}
export interface RestoreSecretRequest {
  SecretId: string | undefined;
}
export interface RestoreSecretResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
}
export interface RotateSecretRequest {
  SecretId: string | undefined;
  ClientRequestToken?: string | undefined;
  RotationLambdaARN?: string | undefined;
  RotationRules?: RotationRulesType | undefined;
  ExternalSecretRotationMetadata?:
    | ExternalSecretRotationMetadataItem[]
    | undefined;
  ExternalSecretRotationRoleArn?: string | undefined;
  RotateImmediately?: boolean | undefined;
}
export interface RotateSecretResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  VersionId?: string | undefined;
}
export interface StopReplicationToReplicaRequest {
  SecretId: string | undefined;
}
export interface StopReplicationToReplicaResponse {
  ARN?: string | undefined;
}
export interface TagResourceRequest {
  SecretId: string | undefined;
  Tags: Tag[] | undefined;
}
export interface UntagResourceRequest {
  SecretId: string | undefined;
  TagKeys: string[] | undefined;
}
export interface UpdateSecretRequest {
  SecretId: string | undefined;
  ClientRequestToken?: string | undefined;
  Description?: string | undefined;
  KmsKeyId?: string | undefined;
  SecretBinary?: Uint8Array | undefined;
  SecretString?: string | undefined;
  Type?: string | undefined;
}
export interface UpdateSecretResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
  VersionId?: string | undefined;
}
export interface UpdateSecretVersionStageRequest {
  SecretId: string | undefined;
  VersionStage: string | undefined;
  RemoveFromVersionId?: string | undefined;
  MoveToVersionId?: string | undefined;
}
export interface UpdateSecretVersionStageResponse {
  ARN?: string | undefined;
  Name?: string | undefined;
}
export interface ValidateResourcePolicyRequest {
  SecretId?: string | undefined;
  ResourcePolicy: string | undefined;
}
export interface ValidationErrorsEntry {
  CheckName?: string | undefined;
  ErrorMessage?: string | undefined;
}
export interface ValidateResourcePolicyResponse {
  PolicyValidationPassed?: boolean | undefined;
  ValidationErrors?: ValidationErrorsEntry[] | undefined;
}
