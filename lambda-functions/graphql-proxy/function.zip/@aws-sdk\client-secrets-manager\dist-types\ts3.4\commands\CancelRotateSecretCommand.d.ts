import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CancelRotateSecretRequest,
  CancelRotateSecretResponse,
} from "../models/models_0";
import {
  SecretsManagerClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../SecretsManagerClient";
export { __MetadataBearer };
export { $Command };
export interface CancelRotateSecretCommandInput
  extends CancelRotateSecretRequest {}
export interface CancelRotateSecretCommandOutput
  extends CancelRotateSecretResponse,
    __MetadataBearer {}
declare const CancelRotateSecretCommand_base: {
  new (
    input: CancelRotateSecretCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CancelRotateSecretCommandInput,
    CancelRotateSecretCommandOutput,
    SecretsManagerClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: CancelRotateSecretCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CancelRotateSecretCommandInput,
    CancelRotateSecretCommandOutput,
    SecretsManagerClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CancelRotateSecretCommand extends CancelRotateSecretCommand_base {
  protected static __types: {
    api: {
      input: CancelRotateSecretRequest;
      output: CancelRotateSecretResponse;
    };
    sdk: {
      input: CancelRotateSecretCommandInput;
      output: CancelRotateSecretCommandOutput;
    };
  };
}
